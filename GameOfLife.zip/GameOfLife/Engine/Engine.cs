﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    //public class EngineOld
    //{
    //    private int width, height;
    //    byte color;

    //    public EngineOld(int width, int height, byte color)
    //    {
    //        this.width = width;
    //        this.height = height;
    //        this.color = color;
    //    }

    //    public void CalcNewStateOLD(byte[] currentState, byte[] next)
    //    {
    //        //for (int ii = 0; ii < width * height; ii++)
    //        Parallel.For(0, width * height, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (ii, loopState) =>
    //        {
    //            int iNum = CalcNumOfNeghours(currentState, ii);

    //            if (iNum >= 4 || iNum < 2)
    //            {
    //                next[ii] = 0; //kill
    //            }
    //            else if (iNum == 3)
    //            {
    //                next[ii] = color; //spawn
    //            }
    //            else if (iNum == 2)
    //            {
    //                next[ii] = currentState[ii]; //survive // copy
    //            }
    //            else
    //            {
    //                throw new Exception("Should no reach here");
    //            }
    //        });



    //    }

    //    private int CalcNumOfNeghours(byte[] currentState, int i)
    //    {
    //        int inum = 0;


    //        int X = i / width;
    //        int Y = i % width;

    //        for (int k = -1; k <= 1; k++)
    //        {
    //            for (int j = -1; j <= 1; j++)
    //            {
    //                int iPos = (X + k) * width + Y + j;
    //                if (CheckIfValidPosition(iPos) && currentState[iPos] == color && !(k == 0 && j == 0))
    //                {
    //                    inum++;
    //                }
    //            }

    //        }

    //        return inum;

    //    }

    //    private bool CheckIfValidPosition(int ipos)
    //    {


    //        int X = ipos / width;
    //        int Y = ipos % width;

    //        if (X >= 0 && X <= width - 1 && Y >= 0 && Y <= height - 1)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }

    //    private int From2DTo1D(int i, int j)
    //    {
    //        return i * width + j;
    //    }
    //}

    public class Engine
    {
        private int width, height;
        byte[] colors;

        public Engine(int width, int height, byte[] colors)
        {
            this.width = width;
            this.height = height;
            this.colors = colors;
        }

        public void CalcNewState(byte[] currentState, byte[] next)
        {
            //for (int ii = 0; ii < width * height; ii++)
            Parallel.For(0, width * height, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (ii, loopState) =>
            {
                int iNum;
                byte bySpawnColor;
                CalcNumOfNeghours(currentState, ii, out iNum, out bySpawnColor);

                if (iNum >= 4 || iNum < 2)
                {
                    next[ii] = 0; //kill
                }
                else if (iNum == 3)
                {
                    next[ii] = bySpawnColor; //spawn
                }
                else if (iNum == 2)
                {
                    next[ii] = currentState[ii]; //survive // copy
                }
                else
                {
                    throw new Exception("Should no reach here");
                }
            });



        }

        private void CalcNumOfNeghours(byte[] currentState, int ii, out int iNum, out byte bySpawnColor)
        {

            int X = ii / width;
            int Y = ii % width;
            int iRed = 0, iGreen = 0;


            for (int k = -1; k <= 1; k++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    int iPos = (X + k) * width + Y + j;
                    if (CheckIfValidPosition(X+k,Y+j) && currentState[iPos] == colors[0] && !(k == 0 && j == 0) )
                    {
                        iGreen++;
                    }
                    else if (CheckIfValidPosition(X + k, Y + j) && currentState[iPos] == colors[1] && !(k == 0 && j == 0))
                    {
                        iRed++;
                    }
                }
            }


            iNum = iRed + iGreen;
            bySpawnColor = iGreen > iRed ? colors[0] : colors[1];
        }



        private bool CheckIfValidPosition(int X,int Y)
        {
            return X >= 0 && X <= width - 1 && Y >= 0 && Y <= height - 1;
        }

        private int From2DTo1D(int i, int j)
        {
            return i * width + j;
        }
    }
}
