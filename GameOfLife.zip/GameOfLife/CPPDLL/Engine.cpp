
#include <memory.h>
#include "Engine.h"
const int sizeOfColArray = 2;
unsigned char cColors[sizeOfColArray];
int iWidth, iHeight;

extern "C"
int Init(int iwidth, int iheight, unsigned char *cCol)
{
	iWidth = iwidth;
	iHeight = iheight;
	memcpy(cColors, cCol, sizeOfColArray);
	return iWidth*iHeight;
}

bool CheckIfValidPosition(int X, int Y)
{
	if (X >= 0 && X <= iWidth - 1 && Y >= 0 && Y <= iHeight - 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}


void CalcNumOfNeghours(unsigned char *currentState, int ii, int *iNum,unsigned char *bySpawnColor,unsigned char *colors)
{

	int X = ii / iWidth;
	int Y = ii % iWidth;
	int iRed = 0, iGreen = 0;
		
	for (int k = -1; k <= 1; k++)
	{
		for (int j = -1; j <= 1; j++)
		{
			int iPos = (X + k) * iWidth + Y + j;
			if (CheckIfValidPosition(X + k, Y + j) && currentState[iPos] == colors[0] && !(k == 0 && j == 0))
			{
				iGreen++;
			}
			else if (CheckIfValidPosition(X + k, Y + j) && currentState[iPos] == colors[1] && !(k == 0 && j == 0))
			{
				iRed++;
			}
		}
	}

	*iNum = iRed + iGreen;
	*bySpawnColor = (iGreen > iRed) ? colors[0] : colors[1];
}

extern "C"
void CalcNewState(unsigned char *curr, unsigned char *nxt)
{
	//char* ptrArr1 = &arr1[0];
	//char* ptrArr2 = &arr2[0];
	//*ptrArr1 = 20;
	//*ptrArr2 = 30;
	int iNum=0;
	
	for (int ii = 0; ii < iWidth * iHeight; ii++)
	{
		unsigned char cCol = 0;
		CalcNumOfNeghours(curr, ii, &iNum, &cCol, cColors);

		if (iNum >= 4 || iNum < 2)
		{
			nxt[ii] = 0; //kill
		}
		else if (iNum == 3)
		{
			nxt[ii] = cCol; //spawn
		}
		else if (iNum == 2)
		{
			nxt[ii] = curr[ii]; //survive // copy
		}

	}
}





